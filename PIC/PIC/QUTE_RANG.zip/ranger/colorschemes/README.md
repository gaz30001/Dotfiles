colorschemes
============

Usage
-----

You can simply clone this repository into your ranger config directory, usually
`~/.config/ranger`, to get access to all the colorschemes.

```sh
cd ~/.config/ranger
git clone https://github.com/ranger/colorschemes.git
```

Creating a new colorscheme
--------------------------

Read about how to create your own colorschemes in
[colorschemes.md](https://github.com/ranger/ranger/blob/master/doc/colorschemes.md)
in the ranger repo.
